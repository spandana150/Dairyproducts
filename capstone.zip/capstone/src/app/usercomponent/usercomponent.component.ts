import { Component, OnInit } from '@angular/core'; 
import { AllProductsService } from '../all-products.service';
import {ActivatedRoute} from '@angular/router';  
import { CartService } from '../cart.service';
import {FormGroup,FormBuilder,Validators} from '@angular/forms'; 
import { ProductsService } from '../products.service';
import { GetallregisterdetailsService } from '../getallregisterdetails.service';

@Component({
  selector: 'app-usercomponent',
  templateUrl: './usercomponent.component.html',
  styleUrls: ['./usercomponent.component.css']
})
export class UsercomponentComponent implements OnInit {
  productForm!:FormGroup;
  user_name:any;
  constructor(private productApi:AllProductsService,private route : ActivatedRoute,private cart:CartService,private formbuilder:FormBuilder,private product : ProductsService,private all : GetallregisterdetailsService) { 

  } 
  final_data:any;
  total:any;
  actual:any;
  actual_cost:any;
  alldetails:any;
  a:any;
  fix:string = "admin";
  p:any={};
  ngOnInit(): void { 
    this.user_name = this.route.snapshot.paramMap.get('a');
    this.productForm = this.formbuilder.group({
      quant:['',Validators.required] 
  })  
  this.all.getalldetails().subscribe(data=>{
    this.alldetails = data;
    console.log(this.alldetails); 
    
  })
  this.productApi.getProductDetails().subscribe(data=>{
    this.final_data = data; 
    console.log(data);
    console.log(this.final_data[0].name);
 }); 

  } 
  display(){
   
  } 
  add(s:any,obj:any){ 
    console.log(s);
    console.log(s.name);
    console.log(this.user_name);
    console.log("hello"); 
    s['user_name']=this.user_name;
    this.actual_cost = s.cost;
    this.actual = s.quantity;
    s.quantity = parseInt(obj.quant);
    s.cost=s.quantity*s.cost; 
    console.log(s.cost);
    console.log(s.user_name+"helloooooooooo");
   this.cart.postProductDetails(s).subscribe(x=>x=x);
   s.quantity = this.actual -   parseInt(obj.quant); 
   s.cost = this.actual_cost;
   //call post to decrement the value 
    this.p['product_name']=s.name;
    this.p['admin_id']=s.admin_id;
    console.log(s.admin_id+"admin name is printed");
    this.p['required']=parseInt(obj.quant);
    console.log(this.p.admin_id+"admin name");
   this.product.editUserDetails(this.p).subscribe(x=>x);
   //this.user_name,s.name,s.quantity,s.cost,s.admin_id
  } 
  admindetails(){
    
  }
  }


