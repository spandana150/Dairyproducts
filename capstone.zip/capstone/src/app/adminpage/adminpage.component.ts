import { Component, OnInit } from '@angular/core'; 
import { AdmingetdetailsService } from '../admingetdetails.service';
import {FormGroup,FormBuilder,Validators} from '@angular/forms'; 
import { Router ,ActivatedRoute} from '@angular/router'; 
import { CartService } from '../cart.service'; 
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {
  name:any;
  productForm!:FormGroup;
  final_data:any;
  password:any;
  products:any;
  constructor(private pro: ProductsService,private route:ActivatedRoute,private formbuilder:FormBuilder,private productApi : AdmingetdetailsService,private router : Router,private cart : CartService) { }

  ngOnInit(): void {
    this.name= this.route.snapshot.paramMap.get('b');
    this.password =  this.route.snapshot.paramMap.get('c');
    console.log(this.name+" in adminpage");
    console.log(this.password);
    // this.productForm = this.formbuilder.group({
    //   quant:['',Validators.required]
    // }) 
    this.productForm = this.formbuilder.group({
      product_name:['',Validators.required],
      product_quantity:['',Validators.required],
      product_cost:['',Validators.required],
      product_img:['',Validators.required],
      admin_id:['',Validators.required]
  }) 
 
}
viewdetails(){
  this.productApi.getAdminDetails(this.name,this.password).subscribe(data=>{
    console.log(this.password+"hehehehehehehe");
    this.final_data = data; 
    console.log(this.final_data[0]);
    //console.log(this.final_data[0].name); 
    //this.router.navigate([`/adminbookings/${this.final_data[0]}`]);
    this.cart.getProductDetails(this.final_data[0].user_id).subscribe(data=>{
      this.products = data;
      console.log(this.products);
    })
 });  
} 
addproduct(val:any){
  console.log(val);
  this.pro.postProductDetails(val).subscribe(data=>{
    
  });
}
}

