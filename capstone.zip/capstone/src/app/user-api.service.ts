import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserApiService {
   readonly APIURL = "https://localhost:44317/api/WeatherForecast"; 
  constructor(private http : HttpClient) { } 
  getStudentName(name:string ,password:string):Observable<string>{ 
     console.log(name);
     return this.http.get<string>(this.APIURL+`?id=${name}&password=${password}`);
  } 
  postDetails(body:any):Observable<any>{
      return this.http.post<any>(this.APIURL,body);
  }

}
