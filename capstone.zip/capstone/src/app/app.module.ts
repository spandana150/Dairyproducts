import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatToolbarModule} from '@angular/material/toolbar';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import { RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { CreateComponent } from './create/create.component';
import { FirstComponent } from './first/first.component';
import {MatFormFieldModule} from '@angular/material/form-field'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UserApiService } from './user-api.service'; 
import { ProductsService } from './products.service';
import { UsercomponentComponent } from './usercomponent/usercomponent.component';
import { UsernotfoundcomponentComponent } from './usernotfoundcomponent/usernotfoundcomponent.component';
import { CartService } from './cart.service';
import { CartComponent } from './cart/cart.component';
import { PaymentsComponent } from './payments/payments.component';
import { OnlinepaymentComponent } from './onlinepayment/onlinepayment.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminbookingsComponent } from './adminbookings/adminbookings.component';
import { RegistrationComponent } from './registration/registration.component';


@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AdminComponent,
    CreateComponent,
    FirstComponent,
    UsercomponentComponent,
    UsernotfoundcomponentComponent,
    
    CartComponent,
    PaymentsComponent,
    OnlinepaymentComponent,
    AdminpageComponent,
    AdminbookingsComponent,
    RegistrationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    RouterModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [UserApiService,ProductsService,CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
