import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  readonly APIURL = "https://localhost:44317/api/Values"; 
  constructor(private http : HttpClient) { } 
 public  getProductDetails(product_name:string ,admin_id:string):Observable<any[]>{ 
     console.log(product_name);
     return this.http.get<any[]>(this.APIURL+`?name=${product_name}&admin=${admin_id}`);
  } 
 public  postProductDetails(s:any):Observable<any>{
  const final = JSON.stringify(s); 
  const headers = { 'content-type': 'application/json'} 
  //console.log(body + final ); 
  return this.http.post<any>(this.APIURL,final,{'headers':headers});
     
  } 
 public  editUserDetails(body:any):Observable<any>{ 
  //console.log(required);
  const headers = { 'content-type': 'application/json'}  
  //const body=JSON.stringify(user);
  const final = JSON.stringify(body);
  console.log(final+"finalll one ");
    return(this.http.put(this.APIURL,body,{'headers':headers}));
  } 
} 


