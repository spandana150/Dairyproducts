import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { UserApiService } from '../user-api.service'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
 productForm! : FormGroup;
  constructor(private formBuilder : FormBuilder,private user : UserApiService,private route : Router) { }

  ngOnInit(): void { 
    this.productForm = this.formBuilder.group({
      user_id:['',Validators.required],
      user_password:['',Validators.required],
      user_address:['',Validators.required],
      user_profile:['',Validators.required],
      user_account:['',Validators.required],
      admin_details:['',Validators.required]
  }) 
  }
  collect(val:any){
     console.log(val.admin_details); 
     this.user.postDetails(val).subscribe(data=>{

     }) 
     this.route.navigate([`/success/${val.user_id}`]);
  } 
}
