import { TestBed } from '@angular/core/testing';

import { GetallregisterdetailsService } from './getallregisterdetails.service';

describe('GetallregisterdetailsService', () => {
  let service: GetallregisterdetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetallregisterdetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
