import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-adminbookings',
  templateUrl: './adminbookings.component.html',
  styleUrls: ['./adminbookings.component.css']
})
export class AdminbookingsComponent implements OnInit {
  details:any;
  constructor(private route : ActivatedRoute) { }

  ngOnInit(): void { 
    this.details = this.route.snapshot.paramMap.get('d');
    console.log(this.details);
  }

}
