import { TestBed } from '@angular/core/testing';

import { AdmingetdetailsService } from './admingetdetails.service';

describe('AdmingetdetailsService', () => {
  let service: AdmingetdetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdmingetdetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
