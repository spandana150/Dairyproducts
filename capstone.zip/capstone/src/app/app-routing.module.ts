import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { CreateComponent } from './create/create.component';
import { FirstComponent } from './first/first.component';
import { UsernotfoundcomponentComponent } from './usernotfoundcomponent/usernotfoundcomponent.component';
import { UsercomponentComponent } from './usercomponent/usercomponent.component';
import { CartComponent } from './cart/cart.component';
import { PaymentsComponent } from './payments/payments.component';
import { OnlinepaymentComponent } from './onlinepayment/onlinepayment.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminbookingsComponent } from './adminbookings/adminbookings.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'',component:AppComponent},
  {path:'first',component:FirstComponent},
  {path:'user',component:UserComponent},
  {path:'admin',component:AdminComponent},
  {path:'create',component:CreateComponent},
  {path:'flop',component:UsernotfoundcomponentComponent},
  {path:'success/:a',component:UsercomponentComponent},
  {path:'login',component:UserComponent},
  {path:'cart/:name',component:CartComponent},
  {path:'payments',component:PaymentsComponent},
  {path:'onlinepayment',component:OnlinepaymentComponent},
  {path:'success_admin/:b/:c',component:AdminpageComponent},
  {path:'adminbookings/:d',component:AdminbookingsComponent},
  {path:'create',component:CreateComponent}
]; 
export const routingComponents =[AppComponent,UserComponent,AdminComponent,CreateComponent];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }






