import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AllProductsService {

  readonly APIURL = "https://localhost:44317/api/ValuesController2"; 
  constructor(private http : HttpClient) { } 
  getProductDetails():Observable<any>{ 
     return this.http.get<any>(this.APIURL);
  }  
} 




   