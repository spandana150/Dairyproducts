import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css']
})
export class PaymentsComponent implements OnInit {
  productForm!: FormGroup;
  demo:any;
  constructor(private formBuilder : FormBuilder,private route : Router) { }

  ngOnInit(): void {
    this.productForm = this.formBuilder.group({
      method:['',Validators.required]
     
    }) 
  } 
  fixpayment(val:any){
    console.log(this.productForm.value+"h");
     console.log(JSON.stringify(val))
     console.log(val);
     console.log("hlowww  ....."+val.method+"...........");
     if(this.productForm.valid)
     if(val.method=="online")
     {
      this.route.navigate(['/onlinepayment']);
      console.log("hello world");
  }
     }
      

}
