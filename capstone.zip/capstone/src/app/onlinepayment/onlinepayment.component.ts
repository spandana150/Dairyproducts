import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinepayment',
  templateUrl: './onlinepayment.component.html',
  styleUrls: ['./onlinepayment.component.css']
})
export class OnlinepaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
