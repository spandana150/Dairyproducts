import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsernotfoundcomponentComponent } from './usernotfoundcomponent.component';

describe('UsernotfoundcomponentComponent', () => {
  let component: UsernotfoundcomponentComponent;
  let fixture: ComponentFixture<UsernotfoundcomponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsernotfoundcomponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsernotfoundcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
