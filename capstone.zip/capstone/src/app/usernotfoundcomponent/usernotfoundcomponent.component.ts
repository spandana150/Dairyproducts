import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usernotfoundcomponent',
  templateUrl: './usernotfoundcomponent.component.html',
  styleUrls: ['./usernotfoundcomponent.component.css']
})
export class UsernotfoundcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
