import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetallregisterdetailsService {

  readonly APIURL = "https://localhost:44317/api/getAllRegister"; 
  constructor(private http : HttpClient) { } 
  getalldetails():Observable<any[]>{ 
     //console.log(name);
     return this.http.get<any[]>(this.APIURL);
  }

} 




