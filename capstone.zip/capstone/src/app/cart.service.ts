import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService { 
  total:any;
   readonly APIURL = "https://localhost:44317/api/ValuesController1"; 
  constructor(private http : HttpClient) { } 
  getProductDetails(user_id:string):Observable<any[]>{ 
     return this.http.get<any[]>(this.APIURL+`?id=${user_id}`);
  } 
  postProductDetails(body:any):Observable<any>{ 
     // this.total = quantity*cost;
    // this.http.post<any>(this.APIURL+`?user=${user_id}&pro_name=${product_name}&pro_quantity=${quantity}&total=${this.total}&admin=${admin_name}`,null);
    const final = JSON.stringify(body); 
    const headers = { 'content-type': 'application/json'} 
    console.log(body + final ); 
    return this.http.post<any>(this.APIURL,final,{'headers':headers});
     //this.http.post<any>(this.APIURL,"{\"user\":\`${user_id}\`,\"product\":\"string\",\"quantity\":0,\"total\":0,\"admin\":\"string\"}");
     
  } 
  removeFromCart(user_name:string,admin:string,product_id:any){
    this.http.delete(this.APIURL+`?id=${user_name}&admin=${admin}&product_name=${product_id}`,product_id);
  } 
}
