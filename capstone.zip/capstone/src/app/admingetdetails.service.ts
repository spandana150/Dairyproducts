import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdmingetdetailsService {
  readonly APIURL = "https://localhost:44317/api/adminget"; 
  constructor(private http : HttpClient) { } 
  getAdminDetails(name:string ,password:string):Observable<any[]>{ 
     console.log(name);
     return this.http.get<any[]>(this.APIURL+`?id=${name}&password=${password}`);
  }

}