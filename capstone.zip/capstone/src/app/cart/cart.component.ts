import { Component, OnInit } from '@angular/core'; 
import { CartService } from '../cart.service'; 
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  status:string="";
  user_name:any;
  arr:any=[];
  constructor(private details:CartService,private route:ActivatedRoute) { 
  }

  ngOnInit(): void {  
    
    this.user_name = this.route.snapshot.paramMap.get('name'); 
    this.details.getProductDetails(this.user_name).subscribe(data=>{
        this.arr = data; 
        console.log(this.arr.user_name);
    }); 
    if(this.arr.quantity==0){
       this.status = "product not available ";
    } 
    else
      this.status = " product available ";
  } 
//  update(){
  //  this.status="product will be delivered by "+this.arr.admin;
  //}

}
