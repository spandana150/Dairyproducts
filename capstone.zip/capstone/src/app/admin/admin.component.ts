import { Component, OnInit } from '@angular/core'; 
import { UserApiService } from '../user-api.service'; 
import {FormGroup,FormBuilder,Validators} from '@angular/forms'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
   arr:any;
   productForm !: FormGroup;
  constructor(private http:UserApiService,private formBuilder:FormBuilder,private router : Router) { }

  ngOnInit(): void { 
    this.productForm = this.formBuilder.group({
      user_id:['',Validators.required],
      user_password:['',Validators.required]
  }) 
}

  check(obj:any){
      this.http.getStudentName(obj.user_id,obj.user_password).subscribe(data=>{
        console.log(data);
        console.log(obj.user_id);
        if(data){
          console.log("user password "+obj.user_password);
          this.router.navigate([`/success_admin/${obj.user_id}/${obj.user_password}`]);
          console.log("success");
        }
        else {
          this.router.navigate(['/flop']);
         console.log("flop");
        }
      })
  }

}
