﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading.Tasks;
using WebApplication4.Controllers;
using WebApplication4.Models;

namespace WebApplication4
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        [HttpGet]
        public Object GetAll(string name, string admin)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

                connection.Open();
                string name1 = name;
                string admin1 = admin;
                string query = "select * from products where product_name=@name AND admin_id=@admin";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@name1", SqlDbType.NVarChar).Value = name;
                cmd.Parameters.Add("@admin1", SqlDbType.NVarChar).Value = admin;
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                   
                    return a;
                }
                else
                {
                   return null;
                }
            }
            catch (Exception)
            {

                throw;
            }
        } 

            [HttpPost]
            public Products PostAll(Products c)
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
                connection.Open();
                string query = "insert into products(product_name,product_quantity,product_cost,product_img,admin_id)" + " values(@user_name,@name,@quantity,@cost,@admin_id); ";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@user_name", c.product_name);
                cmd.Parameters.AddWithValue("@name", c.product_quantity);
                cmd.Parameters.AddWithValue("@quantity", c.product_cost);
                cmd.Parameters.AddWithValue("@cost", c.product_img);
                cmd.Parameters.AddWithValue("@admin_id", c.admin_id);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return c;
                }
                return null;
            }
        
        [HttpPut]

        public ElementsBought PutAllUser(ElementsBought e)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
                connection.Open();
                string query = $"update products set product_quantity=product_quantity-'{e.required}' where product_name='{e.product_name}' AND admin_id='{e.admin_id}';";
                SqlCommand cmd = new SqlCommand(query, connection);
                //cmd.Parameters.AddWithValue("@product_name", e.product_name);
                //cmd.Parameters.AddWithValue("@admin_id", e.admin_id);
                //cmd.Parameters.AddWithValue("@required",e.required);
                var a = cmd.ExecuteReader();
                if (a.HasRows && a.Read())
                    return e;
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        }
}
