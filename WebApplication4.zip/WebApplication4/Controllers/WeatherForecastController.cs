﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Text.Json;
using System.Threading.Tasks;
using WebApplication4.Controllers;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        

        [HttpGet]
        public bool GetAll(string id,string password)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

                connection.Open();
                string id1=id;
                string password1 = password;
                string query = "select * from register where user_id=@id1 AND user_password=@password1";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@id1", SqlDbType.NVarChar).Value = id;
                cmd.Parameters.Add("@password1", SqlDbType.NVarChar).Value = password;
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {

                    return true;
                    
                }
                else {


                   return false;
                }
            }
            catch (Exception)
            {

                throw;
            }



         
            

        }

        [HttpPost]
        public register PostAll(register r)
        {
            string id1, password1,address1,profile1,account1,about1;
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
            connection.Open();
            string query = "insert into register(user_id,user_password,user_address,user_profile,user_account,admin_details) values(@id1,@password1,@address1,@profile1,@account1,@about1); ";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add("@id1", SqlDbType.NVarChar).Value = r.user_id;
            cmd.Parameters.Add("@password1", SqlDbType.NVarChar).Value = r.user_password;
            cmd.Parameters.Add("@address1", SqlDbType.NVarChar).Value = r.user_address;
            cmd.Parameters.Add("@profile1", SqlDbType.NVarChar).Value = r.user_profile;
            cmd.Parameters.Add("@account1", SqlDbType.NVarChar).Value = r.user_account;
            cmd.Parameters.Add("@about1", SqlDbType.NVarChar).Value = r.admin_details;
            if (cmd.ExecuteNonQuery() == 1)
            {
                return r;
            }
            return null;

        }

        [HttpPut]
        public void PutAllAdmin(string name, string admin, int required,int change_in_cost)
        {
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
            connection.Open();
            string name1, admin1;
            int required1,change_in_cost1;
            string query = "update products set product_quantity=product_quantity+@required1 , product_cost=product_cost+@change_in_cost1  where product_name=@name1 AND admin_id=@admin1; ";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add("@name1", SqlDbType.NVarChar).Value = name;
            cmd.Parameters.Add("@admin1", SqlDbType.NVarChar).Value = admin;
            cmd.Parameters.Add("@required1", SqlDbType.NVarChar).Value = required;
            cmd.Parameters.Add("@change_in_cost1", SqlDbType.NVarChar).Value = change_in_cost;
            cmd.ExecuteReader();
        }

    }

}