﻿namespace WebApplication4.Models
{
    public class Cart
    {
       

            public string user_name { get; set; }
            public string name { get; set; }
            public int quantity { get; set; }
            public int cost { get; set; }
            public string admin_id { get; set; }

        
    }
}
