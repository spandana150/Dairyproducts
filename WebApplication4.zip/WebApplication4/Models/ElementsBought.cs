﻿namespace WebApplication4.Models
{
    public class ElementsBought
    {
        public string  admin_id{get;set;} 
        public string product_name{get;set;}
        public int required { get; set; }
    }
}
