﻿namespace WebApplication4.Models
{
    public class Admin
    { 
        public string user_id { get; set; }
        public string user_password { get; set; } 
        public string user_address { get; set; } 
        public string user_profile { get; set; }
        public string user_account { get; set; }
        public string admin_details { get; set; }
    }
}
