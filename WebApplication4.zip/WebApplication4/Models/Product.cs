﻿namespace WebApplication4.Models
{
    public class Product
    {
        
            public string name { get; set; }
            public int quantity { get; set; }
            public int cost { get; set; }
            public string img { get; set; }
            public string admin_id { get; set; }
        
    }
}
