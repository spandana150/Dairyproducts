﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using WebApplication4.Models;

namespace WebApplication4
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController2 : ControllerBase
    {
        [HttpGet]
        public List<Product> GetAll()
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
                connection.Open();
                string query = "select * from products ";
                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                   
                        List<Product> final_products = new List<Product>();
                        Product products = null;
                        while (a.Read())
                        {
                            products = new Product();
                            products.name = a["product_name"].ToString();
                            products.quantity =Convert.ToInt32( a["product_quantity"]);
                            products.cost = Convert.ToInt32(a["product_cost"]);
                            products.img =a["product_img"].ToString();
                            products.admin_id = a["admin_id"].ToString();
                            final_products.Add(products);
                        
                        }
                        return final_products;
                    

                }
                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
