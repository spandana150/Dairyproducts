﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using WebApplication4.Models;

namespace WebApplication4
{
    [Route("api/[controller]")]
    [ApiController]
    public class getAllRegister : ControllerBase
    {
        [HttpGet]
        public List<register> GetAll()
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

                connection.Open();
                string query = "select * from register";
                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows && a.Read())
                {
                    List<register> items = new List<register>();
                    register cart = null;
                    while (a.Read())
                    {
                        cart = new register();
                        cart.user_id = a["user_id"].ToString();
                        cart.user_password= a["user_password"].ToString();
                        cart.user_address = (a["user_address"]).ToString();
                        cart.user_profile = (a["user_profile"]).ToString();
                        cart.user_account = a["user_account"].ToString();
                        cart.admin_details = a["admin_details"].ToString();

                        items.Add(cart);
                    }
                    return items;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
