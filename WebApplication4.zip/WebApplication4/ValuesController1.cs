﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System;
using WebApplication4.Models;
using System.Collections.Generic;

namespace WebApplication4
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController1 : ControllerBase
    {
        

        [HttpGet()]
        public List<User_cart> GetAll(string id)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

                connection.Open();
                string user_id = id;
                string query = "select * from cart where user_name=@user_id OR admin_id=@user_id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@user_id", SqlDbType.NVarChar).Value = id;
                var a = cmd.ExecuteReader();
                if (a.HasRows && a.Read())
                {
                    List<User_cart> items = new List<User_cart>();
                    User_cart cart = null;
                    while (a.Read())
                    {
                        cart = new User_cart();
                        cart.user_name = a["user_name"].ToString();
                        cart.name = a["name"].ToString();
                        cart.quantity = Convert.ToInt32(a["quantity"]);
                        cart.cost = Convert.ToInt32(a["cost"]);
                        cart.admin_id = a["admin_id"].ToString();

                        items.Add(cart);
                    }
                    return items;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPost]
        public Cart PostAll(Cart c)
        { 
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
            connection.Open();
            string query = "insert into cart(user_name,name,quantity,cost,admin_id)"+" values(@user_name,@name,@quantity,@cost,@admin_id); ";
            SqlCommand cmd = new SqlCommand(query, connection);
            
            cmd.Parameters.AddWithValue("@user_name", c.user_name);
            cmd.Parameters.AddWithValue("@name", c.name);
            cmd.Parameters.AddWithValue("@quantity", c.quantity);
            cmd.Parameters.AddWithValue("@cost", c.cost);
            cmd.Parameters.AddWithValue("@admin_id", c.admin_id);

            if (cmd.ExecuteNonQuery() == 1)
            {
                return c;
            }
            return null;
        }
        [HttpDelete]

        public void DeleteAll(string id, string product_name,string admin)
        {
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

            connection.Open();
            string id1, product_name1,admin1;
            string query = "delete  from cart where user_id=@id1 AND name=@product_name1 AND admin=@admin1";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add("@id1", SqlDbType.NVarChar).Value = id;
            cmd.Parameters.Add("@product_name1", SqlDbType.NVarChar).Value = product_name;
            cmd.Parameters.Add("@adin1", SqlDbType.NVarChar).Value = admin;
            var a = cmd.ExecuteReader();
        }
    }

}
