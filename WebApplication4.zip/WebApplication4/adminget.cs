﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System;
using WebApplication4.Models;

namespace WebApplication4
{
    [Route("api/[controller]")]
    [ApiController]
    public class adminget : ControllerBase
    {
        [HttpGet]
        public List<Admin> GetAll(string id,string password)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");

                connection.Open();
                string user_id1=id, user_password1=password;
                string query = "select * from register where user_id=@user_id1 AND user_password=@user_password1";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@user_id1", SqlDbType.NVarChar).Value = id;
                cmd.Parameters.Add("@user_password1", SqlDbType.NVarChar).Value = password;
                var a = cmd.ExecuteReader();
                if (a.HasRows && a.Read())
                {
                    List<Admin> items = new List<Admin>();
                    Admin cart = null;
                    while (a.Read())
                    {
                        cart = new Admin();
                        cart.user_id= a["user_id"].ToString();
                        cart.user_password = a["user_password"].ToString();
                        cart.user_address = a["user_address"].ToString();
                        cart.user_profile = a["user_profile"].ToString();
                        cart.user_account = a["user_account"].ToString();
                        cart.admin_details = a["admin_details"].ToString();

                        items.Add(cart);
                    }
                    return items;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
